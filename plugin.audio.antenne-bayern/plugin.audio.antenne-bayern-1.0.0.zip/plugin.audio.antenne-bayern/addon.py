#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')

def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

add_item('http://mp3channels.webradio.antenne.de/antenne',{"title":'Antenne Bayern'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/oldies-but-goldies',{"title":'Oldies but Goldies'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/chillout',{"title":'Chillout'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/das-schlager-karussell',{"title":'Schlager Karusell'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/hits-fuer-kids',{"title":'Hits fuer Kids'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/top-40',{"title":'Top 40'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/lovesongs',{"title":'Lovesongs'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/black-beatz',{"title":'Black Beatz'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/80er-kulthits',{"title":'0er Kulthits'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/classic-rock-live',{"title":'Classic Rock Live'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.antenne.de/event',{"title":'Antenne Live Event'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.rockantenne.de/rockantenne',{"title":'Rock Antenne'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.rockantenne.de/rockantennelocal01',{"title":'ROCK ANTENNE Erding/Freising/Ebersberg'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.rockantenne.de/alternative',{"title":'ROCK ANTENNE Alternative'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.rockantenne.de/heavy-metal',{"title":'ROCK ANTENNE Heavy Metal'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3channels.webradio.rockantenne.de/classic-perlen',{"title":'ROCK ANTENNE Classic Perlen'},os.path.join(addon_path,'icon.png'))

xbmc.executebuiltin('Container.SetViewMode(100)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#Antenne Bayern