#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')

def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

add_item('http://stream02.iloveradio.de/iloveradio1.mp3',{"title":'I Love Radio'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio2.mp3',{"title":'I Love Dance'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio3.mp3',{"title":'I Love Battle'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio9.mp3',{"title":'I Love Bravo Chats'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio5.mp3',{"title":'I Love Mashup'},os.path.join(addon_path,'icon.png'))
add_item('http://stream02.iloveradio.de/iloveradio6.mp3',{"title":'I Love Dreist'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio4.mp3',{"title":'I Love Bass'},os.path.join(addon_path,'icon.png'))
add_item('http://stream02.iloveradio.de/iloveradio10.mp3',{"title":'I Love Radio/Chill'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio12.mp3',{"title":'I Love Hits History'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio7.mp3',{"title":'I Love About Berlin'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/urbanilr-128-mp3?usid=0-0-H-M-V-03',{"title":'I Love Urban Club Beats'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/grooveilr-128-mp3?usid=0-0-H-M-V-03',{"title":'I Love Groove Night'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/nitroxedmilr-128-mp3?usid=0-0-H-M-V-03',{"title":'I Love Nitrox Edm'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/nitroxdeepilr-128-mp3?usid=0-0-H-M-V-03',{"title":'I Love Nitrox Deep'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio100.mp3',{"title":'I Love Top 100 Germany'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio105.mp3',{"title":'I Love Top 100 Pop'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio103.mp3',{"title":'I Love Top 100 Dance/Djs'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio108.mp3',{"title":'I Love Top 100 Us Hip Hop and Rap'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio104.mp3',{"title":'I Love Top 100 Deutschrap'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio102.mp3',{"title":'I Love Top 100 Club Hits'},os.path.join(addon_path,'icon.png'))
add_item('http://stream04.iloveradio.de/iloveradio109.mp3',{"title":'I Love Top 100 Of 2017'},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo8-nonstop-aac.mp3',{"title":'I Love Bravo Allstars '},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo7-nonstop-aac.mp3',{"title":'I Love Bravo Tubestars'},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo2-nonstop-aac.mp3',{"title":'I Love Bravo OD/Friends'},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo4-nonstop-aac.mp3',{"title":'I Love Bravo the Boys'},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo3-nonstop-aac.mp3',{"title":'I Love Bravo the Girls'},os.path.join(addon_path,'icon.png'))
add_item('http://stream12.iloveradio.de/bravo6-nonstop-aac.mp3',{"title":'I Love Bravo The Hits 2017'},os.path.join(addon_path,'icon.png'))

xbmc.executebuiltin('Container.SetViewMode(100)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#I Love Radio