#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')

def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

add_item('http://webradio.antennevorarlberg.at/live',{"title":'[COLOR yellow]Live[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/rock',{"title":'[COLOR yellow]Rockradio[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/fresh',{"title":'[COLOR yellow]Fresh[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/schlagerkult',{"title":'[COLOR yellow]Schlagerkult[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/lounge',{"title":'[COLOR yellow]Lounge[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/80er',{"title":'[COLOR yellow]80er[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/00er',{"title":'[COLOR yellow]2000er[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/partymix',{"title":'[COLOR yellow]Partymix[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/90er',{"title":'[COLOR yellow]90er[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/hits',{"title":'[COLOR yellow]Top 40[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/lovesongs',{"title":'[COLOR yellow]Love Songs[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/oldies',{"title":'[COLOR yellow]Oldies[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/workout-hits',{"title":'[COLOR yellow]Workout Hits[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/classicrock',{"title":'[COLOR yellow]Classic Rock[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/christkindl',{"title":'[COLOR yellow]Christkindl Radio[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/deutschehits',{"title":'[COLOR yellow]Deutsche Hits[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/disco',{"title":'[COLOR yellow]Disco[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://webradio.antennevorarlberg.at/italiana',{"title":'[COLOR yellow]Musica Italiana[/COLOR]'},os.path.join(addon_path,'icon.png'))


xbmc.executebuiltin('Container.SetViewMode(100)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#Antenne Vorarlberg