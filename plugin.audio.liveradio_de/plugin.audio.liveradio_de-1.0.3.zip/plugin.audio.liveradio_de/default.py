#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys,re,urllib,urllib2
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo("path").decode('utf-8')
baseUrl = 'http://liveradio.de/'
pageUrl = 'http://liveradio.de/internetradio/'
def open_url(url):
    try:
        req = urllib2.Request(url)
        req.add_header('Referer',baseUrl)
        req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36')
        response = urllib2.urlopen(req)
        res=response.read()
        response.close()
        return res
    except Exception, e:
        return None
        xbmcgui.Dialog().ok('ERROR !',str(e))
def regExS0(content):
    match1 = re.search('<li[^<>]*class="active"[^<>]*>[\s\S]*?rel="next" href="(.*?)"',content)
    match2 = re.search('<ul[^<>]*class="pagination"[^<>]*>[\s\S]+page=(.*?)"',content)
    if match1 and match2 :
        addDir('[COLOR red]PAGE '+ str(int(match1.group(1).split('=')[1]) - 1) +' FROM '+ match2.group(1) +' NEXT >[/COLOR]',match1.group(1),2,os.path.join(addon_path,'folder.png'))	
def regExS1(content):
    match = re.search('<div[^<>]*class="tags"[^<>]*>[\s\S]*?<\/div>',content)
    if match:
        for item in re.findall('<a href="/internetradio/(.+?)"',match.group(0)):
            addDir('[COLOR blue]'+os.path.basename(item.upper())+'[/COLOR]',item,1,os.path.join(addon_path,'folder.png'))		
def regExS2(content):
    match = re.search('<div[^<>]*class="station-list"[^<>]*>[\s\S]*?<ul',content)
    if match:
        url=''
        img = ''
        titel = ''
        for data in enumerate(re.findall('alt="(.*?)"|src="(.*?)"| liveradio-player="(.*?)"',match.group(0))):
            if data[1][0]:
                titel=data[1][0]
            if data[1][1]:
                img=data[1][1]
            if data[1][2]:
                url=data[1][2]
                add_item(url,{"title":'[COLOR yellow]'+titel.upper()+'[/COLOR]'},img)
def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+'?url='+str(url)+'&mode='+str(mode)+'&name='+str(name)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='audio', infoLabels={ 'Title': name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()
url=None
name=None
mode=None
iconimage=None
try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass
if mode == None: 
    regExS1(open_url(baseUrl))
    xbmc.executebuiltin('Container.SetViewMode(100)')
if mode == 1:
    content = open_url(pageUrl+url)
    regExS2(content)
    regExS0(content)
    xbmc.executebuiltin('Container.SetViewMode(500)')
if mode == 2:
    content = open_url(baseUrl[:-1]+url)
    regExS2(content)
    regExS0(content)
    xbmc.executebuiltin('Container.SetViewMode(500)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))