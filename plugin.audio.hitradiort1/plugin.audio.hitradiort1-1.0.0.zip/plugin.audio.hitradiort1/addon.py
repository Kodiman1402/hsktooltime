#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')

def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

add_item('http://mp3.hitradiort1.c.nmdn.net/hitradiort1hp/livestream.mp3',{"title":'Hitradio Rt1'},os.path.join(addon_path,'icon.png'))
add_item('http://mp3.hitradiort1.c.nmdn.net/rt1numberoneshp/livestream.mp3',{"title":'Rt1 30 Jahre'},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))
add_item('',{"title":''},os.path.join(addon_path,'icon.png'))

xbmc.executebuiltin('Container.SetViewMode(100)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#Hitradio Rt1