#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')

def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)
	
add_item('http://streams.bigfm.de/bigfm-bw-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]BADEN WÜRTTEMBERG[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-rlp-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]RHEINLAND-PFALZ[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://188.94.98.59:80/stream1',{"title":'[COLOR darkorange]SAARLAND[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-deutschland-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]Deutschland[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-hiphop-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]HIP-HOP[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-deutschrap-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]DEUTSCHRAP[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-usrap-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]US RAP & HIP-HOP[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-dance-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]DANCE[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-sunsetlounge-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]SUNSET LOUNGE[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-reggaevibes-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]REGGAE VIBEZ[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-latinbeats-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]LATIN BEATS[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-groovenight-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]GROOVENIGHT[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-urbanclubbeats-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]URBAN CLUB BEATS[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-nitroxedm-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]DM & PROGRESSIVE[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-nitroxdeep-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]DEEP & TECH HOUSE[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-worldbeats-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]WORLDBEATS[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-turkey-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]Türkey[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-balkan-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]BALKAN[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://streams.bigfm.de/bigfm-orient-128-aac?usid=0-0-H-A-D-30',{"title":'[COLOR darkorange]ORIENT[/COLOR]'},os.path.join(addon_path,'icon.png'))
add_item('http://217.151.152.244/russlandstream',{"title":'[COLOR darkorange]Russland[/COLOR]'},os.path.join(addon_path,'icon.png'))




xbmc.executebuiltin('Container.SetViewMode(100)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#BIG FM