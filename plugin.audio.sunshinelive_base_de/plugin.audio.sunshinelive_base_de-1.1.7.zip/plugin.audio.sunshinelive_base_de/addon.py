#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcaddon,xbmcgui,os,sys

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
icons_path = os.path.join(addon_path,'resources','icon')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')
				
def add_item(url,infolabels,img=''):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

add_item('http://sunshinelive.hoerradar.de/sunshinelive-house-mp3-hq?sABC=593qns88%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497214856',{'title':'[COLOR orange]HOUSE[/COLOR]'},os.path.join(icons_path,'house.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-edm-mp3-hq?sABC=593qnsr4%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497214948',{'title':'[COLOR orange]EDM[/COLOR]'},os.path.join(icons_path,'edm.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-live-mp3-hq?sABC=593qo02n%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497215018',{'title':'[COLOR orange]SUNSHINELIVE[/COLOR]'},os.path.join(icons_path,'live.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-classics-mp3-hq?sABC=593qo07r%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497215102',{'title':'[COLOR orange]CLASSIC[/COLOR]'},os.path.join(icons_path,'classics.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-trance-mp3-hq?sABC=593qo0s3%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497215219',{'title':'[COLOR orange]TRANCE[/COLOR]'},os.path.join(icons_path,'trance.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-hard-mp3-hq?sABC=593r3749%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249609',{'title':'[COLOR orange]HARD[/COLOR]'},os.path.join(icons_path,'hard.png'))
add_item('http://regiocast.hoerradar.de/sunshinelive-techno-mp3-hq?sABC=593r3777%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249655',{'title':'[COLOR orange]TECHNO[/COLOR]'},os.path.join(icons_path,'techno.png'))
add_item('http://sunsl.streamabc.net/sunsl-playlist1-mp3-192-2595213?sABC=593r37q0%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249744',{'title':'[COLOR orange]CLUBSOUND BERLIN[/COLOR]'},os.path.join(icons_path,'clubsound.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-lounge-mp3-hq?sABC=593r37rn%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249770',{'title':'[COLOR orange]LOUNGE[/COLOR]'},os.path.join(icons_path,'lounge.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-90er-mp3-hq?sABC=593r380q%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&amsparams=playerid:Webradio-Player;skey:1497249805',{'title':'[COLOR orange]DIE 90er[/COLOR]'},os.path.join(icons_path,'90er.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-festival-mp3-hq?sABC=593r3837%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&amsparams=playerid:Webradio-Player;skey:1497249847',{'title':'[COLOR orange]FESTIVAL[/COLOR]'},os.path.join(icons_path,'festival.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-handsup-mp3-hq?sABC=593r3869%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249897',{'title':'[COLOR orange]HANDS UP[/COLOR]'},os.path.join(icons_path,'handsup.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-mayday-mp3-hq?sABC=593r3899%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&amsparams=playerid:Webradio-Player;skey:1497249945',{'title':'[COLOR orange]MAYDAY[/COLOR]'},os.path.join(icons_path,'mayday.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-natureone-mp3-hq?sABC=593r38on%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497249978',{'title':'[COLOR orange]NATURE ONE[/COLOR]'},os.path.join(icons_path,'natureone.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-dnb-mp3-hq?sABC=593r38q3%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&context=fHA6LTE=&amsparams=playerid:Webradio-Player;skey:1497250003',{'title':'[COLOR orange]DRUM N BASS[/COLOR]'},os.path.join(icons_path,'dnb.png'))
add_item('http://sunshinelive.hoerradar.de/sunshinelive-timewarp-mp3-hq?sABC=593r38s3%230%23161r99q226ro3p2992s33r62o26qp9n5%23Jroenqvb-Cynlre&amsparams=playerid:Webradio-Player;skey:1497250035',{'title':'[COLOR orange]TIME WARP[/COLOR]'},os.path.join(icons_path,'timewarp.png'))

if addon.getSetting('sort') == 'true':
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)

xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('view-mode'))
xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=True, updateListing=False, cacheToDisc=False)

#SUNSHINELIVE